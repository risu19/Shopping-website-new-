# ShopEase – Shopping Website

A responsive e-commerce frontend built with **HTML, CSS and JavaScript**.

## Features
- Responsive layout for desktop and mobile
- Product cards with category labels and prices
- Live product search
- Category filtering (Fashion, Tech and Home)
- Add-to-cart interaction with live cart count
- Simple feedback toast and demo cart summary

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a browser.
3. Search products, filter categories and add items to the cart.

## Technologies
HTML5 · CSS3 · Vanilla JavaScript

## Project note
This is a frontend portfolio/demo project. It does not process real payments or store orders.

**Author:** Rishita Dubey
