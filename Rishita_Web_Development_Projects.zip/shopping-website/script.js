const products=[
 {id:1,name:"Classic Sneakers",category:"Fashion",price:1899,emoji:"👟"},
 {id:2,name:"Everyday Backpack",category:"Fashion",price:1299,emoji:"🎒"},
 {id:3,name:"Wireless Headphones",category:"Tech",price:2499,emoji:"🎧"},
 {id:4,name:"Smart Watch",category:"Tech",price:3299,emoji:"⌚"},
 {id:5,name:"Ceramic Coffee Mug",category:"Home",price:399,emoji:"☕"},
 {id:6,name:"Desk Plant Pot",category:"Home",price:549,emoji:"🪴"},
 {id:7,name:"Minimal Tote Bag",category:"Fashion",price:699,emoji:"👜"},
 {id:8,name:"Portable Speaker",category:"Tech",price:1599,emoji:"🔊"}
];
let category="All",cart=0;
const grid=document.getElementById("productGrid"),search=document.getElementById("searchInput");
function render(){const term=search.value.toLowerCase();const shown=products.filter(p=>(category==="All"||p.category===category)&&p.name.toLowerCase().includes(term));
 grid.innerHTML=shown.length?shown.map(p=>`<article class="card"><div class="photo">${p.emoji}</div><div class="details"><span class="tag">${p.category}</span><h3>${p.name}</h3><div class="buy-row"><span class="price">₹${p.price.toLocaleString("en-IN")}</span><button class="add" data-id="${p.id}">Add +</button></div></div></article>`).join(""):'<p>No products found. Try another search.</p>';
}
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{document.querySelector(".filter.active").classList.remove("active");btn.classList.add("active");category=btn.dataset.category;render()}));
search.addEventListener("input",render);
grid.addEventListener("click",e=>{const btn=e.target.closest(".add");if(!btn)return;cart++;document.getElementById("cartCount").textContent=cart;const toast=document.getElementById("toast");toast.textContent="Product added to your cart!";toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),1500)});
document.getElementById("cartButton").addEventListener("click",()=>alert(`You have ${cart} item(s) in your demo cart.`));
render();