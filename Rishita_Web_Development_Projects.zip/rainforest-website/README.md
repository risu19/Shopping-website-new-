# Rainforest – The Living Green

A responsive educational website introducing rainforest ecosystems and biodiversity.

## Features
- Nature-inspired responsive design
- Sections for rainforest discovery, wildlife and conservation
- Informational highlights and animal cards
- Mobile-friendly navigation and layout
- External conservation learning link

## Run locally
1. Download or clone this repository.
2. Open `index.html` in any modern browser.

## Technologies
HTML5 · CSS3

## Project note
This is an educational frontend project. The statistics are presented as broad estimates and the site is not affiliated with a conservation organization.

**Author:** Rishita Dubey
